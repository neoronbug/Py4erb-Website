"""
This file defines actions, i.e. functions the URLs are mapped into
The @action(path) decorator exposed the function at URL:

    http://127.0.0.1:8000/{app_name}/{path}

If app_name == '_default' then simply

    http://127.0.0.1:8000/{path}

If path == 'index' it can be omitted:

    http://127.0.0.1:8000/

The path follows the bottlepy syntax.

@action.uses('generic.html')  indicates that the action uses the generic.html template
@action.uses(session)         indicates that the action uses the session
@action.uses(db)              indicates that the action uses the db
@action.uses(T)               indicates that the action uses the i18n & pluralization
@action.uses(auth.user)       indicates that the action requires a logged in user
@action.uses(auth)            indicates that the action requires the auth object

session, db, T, auth, and tempates are examples of Fixtures.
Warning: Fixtures MUST be declared with @action.uses({fixtures}) else your app will result in undefined behavior
"""

import uuid

from py4web import action, request, abort, redirect, URL, Field,Session
from py4web.utils.form import Form, FormStyleBulma
from py4web.utils.url_signer import URLSigner

from yatl.helpers import A
from . common import db, session, T, cache, auth, signed_url


url_signer = URLSigner(session)


@action('index', method="GET")
@action.uses('index.html', db, auth.user)
def show_products():
    sort_param = request.params.get('sort')
    if sort_param is None:
        rows = db(db.address_book.current_user_record == auth.current_user.get('email') ).select()
        for row in rows:
            sub_row_list = ""
            sub_rows = db(db.address_book_phone_no.user_id == row.id ).select()
            for sub_row in sub_rows:
                sub_row_list = sub_row_list + f"{sub_row.phone_no}, ({sub_row.kind}) "
            row["sub"] = sub_row_list
    return dict(rows=rows, url_signer=url_signer)

@action('show_phone_no/<contact_id>', method='GET')
@action.uses('edit_phone_no.html', db, auth.user)
def show_phone_no(contact_id=None):
    record = db.address_book[contact_id]
    contact_det = contact_id
    user_name = record
    rows = db(db.address_book_phone_no.user_id == contact_id ).select()
    return dict(rows=rows, contact=contact_det, name=user_name, url_signer=url_signer)


@action('edit_phone_contact/<contact_id>', method=['GET', 'POST'])
@action.uses('edit_phone_no_form.html', session, db)
def edit_phone_contact(contact_id=None):
    p = db.address_book_phone_no[contact_id]
    name_record = db.address_book[contact_id]
    if p is None:
        redirect(URL('index'))
    form = Form(db.address_book_phone_no, record=p, deletable=False, csrf_session=session, formstyle=FormStyleBulma)
    if form.accepted:
        redirect(URL('index'))
    return dict(form=form)

@action('delete_phone_contact/<contact_id>', method='GET')
@action.uses('index.html', session, db, url_signer.verify())
def delete_phone_contact(contact_id=None):
    p = db.address_book_phone_no[contact_id]
    if p is None:
        redirect(URL('index'))
    else:
        db(contact_id == db.address_book_phone_no.id).delete()
        redirect(URL('index'))
    return dict()

@action('add_phone_contact/<contact_id>', method=['GET', 'POST'])
@action.uses('add_phone_no_form.html', session, db, auth.user)
def add_phone_contact_fun(contact_id=None):
    name_record = db.address_book[contact_id]
    main_id = contact_id
    form = Form([Field('phone_no'), Field('kind')],record=dict(phone_no="", kind=""), deletable=False,csrf_session=session,formstyle=FormStyleBulma)
    if form.accepted:
        print(form.vars)
        db.address_book_phone_no.insert(user_id=main_id, phone_no=form.vars['phone_no'], kind=form.vars['kind'])
        redirect(URL('index'))
    return dict(form=form, name=name_record)


@action('add_contact', method=['GET', 'POST'])
@action.uses('add_form.html', session, db, auth.user)
def add_contact_fun():
    
    form = Form(db.address_book,csrf_session=session, formstyle=FormStyleBulma)
    if form.accepted:
        redirect(URL('index'))
    return dict(form=form)


@action('delete_contact/<contact_id>', method='GET')
@action.uses('index.html', session, db, url_signer.verify())
def delete_contact(contact_id=None):
    p = db.address_book[contact_id]
    if p is None:
        redirect(URL('index'))
    else:
        db(contact_id == db.address_book.id).delete()
        redirect(URL('index'))
    return dict()


@action('edit_contact/<contact_id>', method=['GET', 'POST'])
@action.uses('add_form.html', session, db)
def edit_contact(contact_id=None):
    p = db.address_book[contact_id]
    if p is None:
        redirect(URL('index'))
    form = Form(db.address_book, record=p, deletable=False, csrf_session=session, formstyle=FormStyleBulma)
    if form.accepted:
        redirect(URL('index'))
    return dict(form=form)