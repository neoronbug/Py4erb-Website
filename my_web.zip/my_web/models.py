"""
This file defines the database models
"""
import datetime

from . common import db, Field, auth
from pydal.validators import *

### Define your table below
#
# db.define_table('thing', Field('name'))
#
## always commit your models to avoid problems later
#
# db.commit()
#


def get_user_email():
    return auth.current_user.get('email')

def get_time():
    return datetime.datetime.utcnow()


db.define_table(
    'address_book',
    Field('first_name'),
    Field('last_name'),
    Field('current_user_record', default = get_user_email)

)

db.address_book.id.readable = False
db.address_book.current_user_record.readable = False

# db.define_table(
#     'address_book_phone_no',
#     Field('user_id'),
#     Field('last_name'),
# )

# db.address_book_phone_no.id.readable = False

db.commit()
